const bundler = {
  externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming", "pg"],
  sourcemap: true
};

export { bundler };
