import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { createTool } from '@mastra/core/tools';
import pg from 'pg';
import TelegramBot from 'node-telegram-bot-api';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

init(inngest);
const inngestFunctions = [];
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const { Pool: Pool$2 } = pg;
const pool$2 = new Pool$2({
  connectionString: process.env.DATABASE_URL
});
const getEventsTool = createTool({
  id: "get-events",
  description: "Get available events, categories, and cities. Use this tool when the user wants to see available events, browse by category or city, or needs information about what's available.",
  inputSchema: z.object({
    categoryId: z.number().optional().describe("Filter by category ID (optional)"),
    cityId: z.number().optional().describe("Filter by city ID (optional)"),
    eventId: z.number().optional().describe("Get specific event by ID (optional)"),
    includeCategories: z.boolean().optional().describe("Include list of all categories"),
    includeCities: z.boolean().optional().describe("Include list of all cities")
  }),
  outputSchema: z.object({
    events: z.array(
      z.object({
        id: z.number(),
        name: z.string(),
        description: z.string().nullable(),
        categoryName: z.string(),
        cityName: z.string(),
        date: z.string().nullable(),
        time: z.string().nullable(),
        price: z.number(),
        availableSeats: z.number()
      })
    ),
    categories: z.array(
      z.object({
        id: z.number(),
        name: z.string(),
        nameRu: z.string()
      })
    ).optional(),
    cities: z.array(
      z.object({
        id: z.number(),
        name: z.string()
      })
    ).optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [getEventsTool] Starting execution with params:", context);
    try {
      let eventsQuery = `
        SELECT 
          e.id, 
          e.name, 
          e.description, 
          c.name_ru as category_name, 
          ci.name as city_name,
          e.date::text,
          e.time::text,
          e.price::numeric as price,
          e.available_seats
        FROM events e
        JOIN categories c ON e.category_id = c.id
        JOIN cities ci ON e.city_id = ci.id
        WHERE e.available_seats > 0
      `;
      const params = [];
      let paramIndex = 1;
      if (context.eventId) {
        eventsQuery += ` AND e.id = $${paramIndex}`;
        params.push(context.eventId);
        paramIndex++;
      }
      if (context.categoryId) {
        eventsQuery += ` AND e.category_id = $${paramIndex}`;
        params.push(context.categoryId);
        paramIndex++;
      }
      if (context.cityId) {
        eventsQuery += ` AND e.city_id = $${paramIndex}`;
        params.push(context.cityId);
        paramIndex++;
      }
      eventsQuery += " ORDER BY e.date ASC";
      logger?.info("\u{1F4DD} [getEventsTool] Executing events query...");
      const eventsResult = await pool$2.query(eventsQuery, params);
      const events = eventsResult.rows.map((row) => ({
        id: row.id,
        name: row.name,
        description: row.description,
        categoryName: row.category_name,
        cityName: row.city_name,
        date: row.date,
        time: row.time,
        price: parseFloat(row.price) || 0,
        availableSeats: row.available_seats
      }));
      let categories;
      if (context.includeCategories) {
        logger?.info("\u{1F4DD} [getEventsTool] Fetching categories...");
        const catResult = await pool$2.query(
          "SELECT id, name, name_ru FROM categories ORDER BY name_ru"
        );
        categories = catResult.rows.map((row) => ({
          id: row.id,
          name: row.name,
          nameRu: row.name_ru
        }));
      }
      let cities;
      if (context.includeCities) {
        logger?.info("\u{1F4DD} [getEventsTool] Fetching cities...");
        const cityResult = await pool$2.query(
          "SELECT id, name FROM cities ORDER BY name"
        );
        cities = cityResult.rows.map((row) => ({
          id: row.id,
          name: row.name
        }));
      }
      logger?.info(
        `\u2705 [getEventsTool] Found ${events.length} events`
      );
      return { events, categories, cities };
    } catch (error) {
      logger?.error("\u274C [getEventsTool] Error:", error);
      throw error;
    }
  }
});

const { Pool: Pool$1 } = pg;
const pool$1 = new Pool$1({
  connectionString: process.env.DATABASE_URL
});
function generateOrderCode() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `ORD-${code}`;
}
async function withTransaction(fn) {
  const client = await pool$1.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
const createOrderTool = createTool({
  id: "create-order",
  description: "Create a new order for an event ticket. Use this when the user wants to book or purchase a ticket for an event. Collects customer information and creates the order.",
  inputSchema: z.object({
    eventId: z.number().describe("The ID of the event to book"),
    customerName: z.string().describe("Full name of the customer"),
    customerPhone: z.string().describe("Customer phone number"),
    customerEmail: z.string().optional().describe("Customer email (optional)"),
    seatsCount: z.number().default(1).describe("Number of seats to book"),
    telegramChatId: z.string().optional().describe("Telegram chat ID for notifications"),
    telegramUsername: z.string().optional().describe("Telegram username")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    orderCode: z.string().optional(),
    orderId: z.number().optional(),
    eventName: z.string().optional(),
    eventDate: z.string().optional(),
    eventTime: z.string().optional(),
    cityName: z.string().optional(),
    customerName: z.string().optional(),
    customerPhone: z.string().optional(),
    customerEmail: z.string().optional(),
    seatsCount: z.number().optional(),
    totalPrice: z.number().optional(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [createOrderTool] Creating order with params:", context);
    try {
      return await withTransaction(async (client) => {
        const eventResult = await client.query(
          `SELECT e.*, c.name_ru as category_name, ci.name as city_name 
           FROM events e 
           JOIN categories c ON e.category_id = c.id 
           JOIN cities ci ON e.city_id = ci.id 
           WHERE e.id = $1
           FOR UPDATE`,
          [context.eventId]
        );
        if (eventResult.rows.length === 0) {
          logger?.warn("\u26A0\uFE0F [createOrderTool] Event not found:", context.eventId);
          return {
            success: false,
            message: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
          };
        }
        const event = eventResult.rows[0];
        const seatsCount = context.seatsCount || 1;
        if (event.available_seats < seatsCount) {
          logger?.warn("\u26A0\uFE0F [createOrderTool] Not enough seats available");
          return {
            success: false,
            message: `\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u043C\u0435\u0441\u0442. \u0414\u043E\u0441\u0442\u0443\u043F\u043D\u043E: ${event.available_seats}`
          };
        }
        const orderCode = generateOrderCode();
        const totalPrice = parseFloat(event.price) * seatsCount;
        logger?.info("\u{1F4DD} [createOrderTool] Inserting order with transaction...");
        const orderResult = await client.query(
          `INSERT INTO orders 
           (order_code, event_id, customer_name, customer_phone, customer_email, 
            telegram_chat_id, telegram_username, seats_count, total_price, status, payment_status)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending', 'pending')
           RETURNING id`,
          [
            orderCode,
            context.eventId,
            context.customerName,
            context.customerPhone,
            context.customerEmail || null,
            context.telegramChatId || null,
            context.telegramUsername || null,
            seatsCount,
            totalPrice
          ]
        );
        await client.query(
          "UPDATE events SET available_seats = available_seats - $1 WHERE id = $2",
          [seatsCount, context.eventId]
        );
        logger?.info("\u2705 [createOrderTool] Order created:", orderCode);
        return {
          success: true,
          orderCode,
          orderId: orderResult.rows[0].id,
          eventName: event.name,
          eventDate: event.date?.toISOString?.()?.split("T")[0] || String(event.date),
          eventTime: event.time || "00:00",
          cityName: event.city_name,
          customerName: context.customerName,
          customerPhone: context.customerPhone,
          customerEmail: context.customerEmail,
          seatsCount,
          totalPrice,
          message: `\u0417\u0430\u043A\u0430\u0437 ${orderCode} \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u0441\u043E\u0437\u0434\u0430\u043D! \u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435: ${event.name}, ${event.city_name}. \u0421\u0443\u043C\u043C\u0430: ${totalPrice} \u0440\u0443\u0431.`
        };
      });
    } catch (error) {
      logger?.error("\u274C [createOrderTool] Error:", error);
      return {
        success: false,
        message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0437\u0430\u043A\u0430\u0437\u0430. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435."
      };
    }
  }
});

const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
const manageOrderTool = createTool({
  id: "manage-order",
  description: "Manage existing orders - confirm payment, reject payment, cancel order, or get order details. Use this when admin needs to approve/reject a payment or when checking order status.",
  inputSchema: z.object({
    action: z.enum(["get", "confirm_payment", "reject_payment", "cancel", "list_pending"]).describe("Action to perform on the order"),
    orderCode: z.string().optional().describe("Order code (required for get, confirm, reject, cancel actions)"),
    orderId: z.number().optional().describe("Order ID (alternative to orderCode for confirm/reject)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    order: z.object({
      id: z.number(),
      orderCode: z.string(),
      eventName: z.string(),
      categoryName: z.string(),
      cityName: z.string(),
      eventDate: z.string().nullable(),
      eventTime: z.string().nullable(),
      customerName: z.string(),
      customerPhone: z.string(),
      customerEmail: z.string().nullable(),
      telegramUsername: z.string().nullable(),
      seatsCount: z.number(),
      totalPrice: z.number(),
      status: z.string(),
      paymentStatus: z.string(),
      createdAt: z.string()
    }).optional(),
    orders: z.array(
      z.object({
        id: z.number(),
        orderCode: z.string(),
        eventName: z.string(),
        customerName: z.string(),
        totalPrice: z.number(),
        status: z.string(),
        paymentStatus: z.string()
      })
    ).optional(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [manageOrderTool] Action:", context.action, "OrderCode:", context.orderCode);
    try {
      if (context.action === "list_pending") {
        logger?.info("\u{1F4DD} [manageOrderTool] Listing pending orders...");
        const result = await pool.query(
          `SELECT o.id, o.order_code, e.name as event_name, o.customer_name, 
                  o.total_price::numeric, o.status, o.payment_status
           FROM orders o
           JOIN events e ON o.event_id = e.id
           WHERE o.payment_status = 'pending'
           ORDER BY o.created_at DESC
           LIMIT 20`
        );
        const orders = result.rows.map((row2) => ({
          id: row2.id,
          orderCode: row2.order_code,
          eventName: row2.event_name,
          customerName: row2.customer_name,
          totalPrice: parseFloat(row2.total_price),
          status: row2.status,
          paymentStatus: row2.payment_status
        }));
        logger?.info(`\u2705 [manageOrderTool] Found ${orders.length} pending orders`);
        return {
          success: true,
          orders,
          message: `\u041D\u0430\u0439\u0434\u0435\u043D\u043E ${orders.length} \u0437\u0430\u043A\u0430\u0437\u043E\u0432, \u043E\u0436\u0438\u0434\u0430\u044E\u0449\u0438\u0445 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F`
        };
      }
      if (!context.orderCode && !context.orderId) {
        return {
          success: false,
          message: "\u041A\u043E\u0434 \u0437\u0430\u043A\u0430\u0437\u0430 \u0438\u043B\u0438 ID \u0437\u0430\u043A\u0430\u0437\u0430 \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u0435\u043D \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"
        };
      }
      let orderResult;
      if (context.orderId) {
        orderResult = await pool.query(
          `SELECT o.*, e.name as event_name, e.date::text as event_date, e.time::text as event_time,
                  c.name_ru as category_name, ci.name as city_name
           FROM orders o
           JOIN events e ON o.event_id = e.id
           JOIN categories c ON e.category_id = c.id
           JOIN cities ci ON e.city_id = ci.id
           WHERE o.id = $1`,
          [context.orderId]
        );
      } else {
        orderResult = await pool.query(
          `SELECT o.*, e.name as event_name, e.date::text as event_date, e.time::text as event_time,
                  c.name_ru as category_name, ci.name as city_name
           FROM orders o
           JOIN events e ON o.event_id = e.id
           JOIN categories c ON e.category_id = c.id
           JOIN cities ci ON e.city_id = ci.id
           WHERE o.order_code = $1`,
          [context.orderCode]
        );
      }
      if (orderResult.rows.length === 0) {
        logger?.warn("\u26A0\uFE0F [manageOrderTool] Order not found:", context.orderCode);
        return {
          success: false,
          message: `\u0417\u0430\u043A\u0430\u0437 ${context.orderCode} \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D`
        };
      }
      const row = orderResult.rows[0];
      const order = {
        id: row.id,
        orderCode: row.order_code,
        eventName: row.event_name,
        categoryName: row.category_name,
        cityName: row.city_name,
        eventDate: row.event_date,
        eventTime: row.event_time,
        customerName: row.customer_name,
        customerPhone: row.customer_phone,
        customerEmail: row.customer_email,
        telegramUsername: row.telegram_username,
        seatsCount: row.seats_count,
        totalPrice: parseFloat(row.total_price),
        status: row.status,
        paymentStatus: row.payment_status,
        createdAt: row.created_at?.toISOString() || ""
      };
      if (context.action === "get") {
        logger?.info("\u2705 [manageOrderTool] Order found:", order.orderCode);
        return {
          success: true,
          order,
          message: `\u0417\u0430\u043A\u0430\u0437 ${order.orderCode} \u043D\u0430\u0439\u0434\u0435\u043D`
        };
      }
      if (context.action === "confirm_payment") {
        await pool.query(
          "UPDATE orders SET payment_status = 'confirmed', status = 'confirmed', updated_at = NOW() WHERE id = $1",
          [order.id]
        );
        order.paymentStatus = "confirmed";
        order.status = "confirmed";
        logger?.info("\u2705 [manageOrderTool] Payment confirmed:", order.orderCode);
        return {
          success: true,
          order,
          message: `\u2705 \u041E\u043F\u043B\u0430\u0442\u0430 \u0437\u0430\u043A\u0430\u0437\u0430 ${order.orderCode} \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430! \u041A\u043B\u0438\u0435\u043D\u0442: ${order.customerName}, \u0421\u0443\u043C\u043C\u0430: ${order.totalPrice} \u0440\u0443\u0431.`
        };
      }
      if (context.action === "reject_payment") {
        await pool.query(
          "UPDATE orders SET payment_status = 'rejected', status = 'rejected', updated_at = NOW() WHERE id = $1",
          [order.id]
        );
        await pool.query(
          "UPDATE events SET available_seats = available_seats + $1 WHERE id = $2",
          [row.seats_count, row.event_id]
        );
        order.paymentStatus = "rejected";
        order.status = "rejected";
        logger?.info("\u274C [manageOrderTool] Payment rejected:", order.orderCode);
        return {
          success: true,
          order,
          message: `\u274C \u041E\u043F\u043B\u0430\u0442\u0430 \u0437\u0430\u043A\u0430\u0437\u0430 ${order.orderCode} \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0430. \u041C\u0435\u0441\u0442\u0430 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u044B \u0432 \u043F\u0440\u043E\u0434\u0430\u0436\u0443.`
        };
      }
      if (context.action === "cancel") {
        await pool.query(
          "UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = $1",
          [order.id]
        );
        if (row.payment_status !== "rejected") {
          await pool.query(
            "UPDATE events SET available_seats = available_seats + $1 WHERE id = $2",
            [row.seats_count, row.event_id]
          );
        }
        order.status = "cancelled";
        logger?.info("\u{1F6AB} [manageOrderTool] Order cancelled:", order.orderCode);
        return {
          success: true,
          order,
          message: `\u0417\u0430\u043A\u0430\u0437 ${order.orderCode} \u043E\u0442\u043C\u0435\u043D\u0451\u043D`
        };
      }
      return {
        success: false,
        message: "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"
      };
    } catch (error) {
      logger?.error("\u274C [manageOrderTool] Error:", error);
      return {
        success: false,
        message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u0437\u0430\u043A\u0430\u0437\u0430"
      };
    }
  }
});

const sendTelegramNotificationTool = createTool({
  id: "send-telegram-notification",
  description: "Send a notification message to a Telegram chat or channel. Use this to notify admins about new orders, payment confirmations, or send updates to customers.",
  inputSchema: z.object({
    chatId: z.string().describe("Telegram chat ID or channel ID to send the message to"),
    message: z.string().describe("The message text to send"),
    parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).optional().default("HTML").describe("Parse mode for message formatting")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [sendTelegramNotificationTool] Sending to chat:", context.chatId);
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      logger?.error("\u274C [sendTelegramNotificationTool] TELEGRAM_BOT_TOKEN not set");
      return {
        success: false,
        error: "Telegram bot token not configured"
      };
    }
    try {
      const response = await fetch(
        `https://api.telegram.org/bot${botToken}/sendMessage`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            chat_id: context.chatId,
            text: context.message,
            parse_mode: context.parseMode || "HTML"
          })
        }
      );
      const data = await response.json();
      if (data.ok) {
        logger?.info("\u2705 [sendTelegramNotificationTool] Message sent, ID:", data.result.message_id);
        return {
          success: true,
          messageId: data.result.message_id
        };
      } else {
        logger?.error("\u274C [sendTelegramNotificationTool] Telegram API error:", data.description);
        return {
          success: false,
          error: data.description || "Failed to send message"
        };
      }
    } catch (error) {
      logger?.error("\u274C [sendTelegramNotificationTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.TELEGRAM_ADMIN_CHAT_ID;
let bot = null;
function getBot() {
  if (!TELEGRAM_BOT_TOKEN) {
    console.error("\u274C [TelegramAdmin] TELEGRAM_BOT_TOKEN not configured");
    return null;
  }
  if (!bot) {
    bot = new TelegramBot(TELEGRAM_BOT_TOKEN);
  }
  return bot;
}
async function sendOrderNotificationToAdmin(order) {
  const telegramBot = getBot();
  if (!telegramBot) {
    console.error("\u274C [TelegramAdmin] Bot not initialized");
    return false;
  }
  if (!ADMIN_CHAT_ID) {
    console.error("\u274C [TelegramAdmin] TELEGRAM_ADMIN_CHAT_ID not configured");
    return false;
  }
  console.log("\u{1F4E4} [TelegramAdmin] Sending order notification to admin:", order.orderCode);
  const message = `\u{1F3AB} *\u041A\u043B\u0438\u0435\u043D\u0442 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043E\u043F\u043B\u0430\u0442\u044B!*

\u{1F4CB} *\u041A\u043E\u0434 \u0437\u0430\u043A\u0430\u0437\u0430:* \`${order.orderCode}\`

\u{1F3AD} *\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435:* ${escapeMarkdown(order.eventName)}
\u{1F4CD} *\u0413\u043E\u0440\u043E\u0434:* ${escapeMarkdown(order.cityName)}
\u{1F4C5} *\u0414\u0430\u0442\u0430:* ${order.eventDate}
\u23F0 *\u0412\u0440\u0435\u043C\u044F:* ${order.eventTime}

\u{1F464} *\u041F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044C:* ${escapeMarkdown(order.customerName)}
\u{1F4DE} *\u0422\u0435\u043B\u0435\u0444\u043E\u043D:* ${escapeMarkdown(order.customerPhone)}
${order.customerEmail ? `\u{1F4E7} *Email:* ${escapeMarkdown(order.customerEmail)}` : ""}

\u{1F39F} *\u041C\u0435\u0441\u0442:* ${order.seatsCount}
\u{1F4B0} *\u0421\u0443\u043C\u043C\u0430:* ${order.totalPrice} \u20BD

\u23F3 *\u0421\u0442\u0430\u0442\u0443\u0441:* \u041A\u043B\u0438\u0435\u043D\u0442 \u0432\u044B\u0431\u0438\u0440\u0430\u0435\u0442 \u0441\u043F\u043E\u0441\u043E\u0431 \u043E\u043F\u043B\u0430\u0442\u044B`;
  const keyboard = {
    inline_keyboard: [
      [
        { text: "\u2705 \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043E\u043F\u043B\u0430\u0442\u0443", callback_data: `confirm_${order.orderId}` },
        { text: "\u274C \u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C", callback_data: `reject_${order.orderId}` }
      ]
    ]
  };
  try {
    await telegramBot.sendMessage(ADMIN_CHAT_ID, message, {
      parse_mode: "Markdown",
      reply_markup: keyboard
    });
    console.log("\u2705 [TelegramAdmin] Notification sent successfully");
    return true;
  } catch (error) {
    console.error("\u274C [TelegramAdmin] Failed to send notification:", error);
    return false;
  }
}
async function updateOrderMessageStatus(chatId, messageId, orderCode, status, adminUsername) {
  const telegramBot = getBot();
  if (!telegramBot) {
    return false;
  }
  const statusText = status === "confirmed" ? "\u2705 *\u041E\u041F\u041B\u0410\u0422\u0410 \u041F\u041E\u0414\u0422\u0412\u0415\u0420\u0416\u0414\u0415\u041D\u0410*" : "\u274C *\u0417\u0410\u041A\u0410\u0417 \u041E\u0422\u041A\u041B\u041E\u041D\u0401\u041D*";
  const adminInfo = adminUsername ? `
\u{1F464} \u041E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043B: @${adminUsername}` : "";
  const timestamp = (/* @__PURE__ */ new Date()).toLocaleString("ru-RU", { timeZone: "Europe/Moscow" });
  const newText = `${statusText}

\u{1F4CB} *\u041A\u043E\u0434 \u0437\u0430\u043A\u0430\u0437\u0430:* \`${orderCode}\`
\u{1F4C5} *\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E:* ${timestamp}${adminInfo}`;
  try {
    await telegramBot.editMessageText(newText, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    });
    console.log(`\u2705 [TelegramAdmin] Message updated for order ${orderCode}`);
    return true;
  } catch (error) {
    console.error("\u274C [TelegramAdmin] Failed to update message:", error);
    return false;
  }
}
async function answerCallbackQuery(callbackQueryId, text) {
  const telegramBot = getBot();
  if (!telegramBot) {
    return false;
  }
  try {
    await telegramBot.answerCallbackQuery(callbackQueryId, { text });
    return true;
  } catch (error) {
    console.error("\u274C [TelegramAdmin] Failed to answer callback:", error);
    return false;
  }
}
function escapeMarkdown(text) {
  return text.replace(/[_*[\]()~`>#+=|{}.!-]/g, "\\$&");
}

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // No workflows or agents - using simple Telegram admin notifications
  workflows: {},
  agents: {},
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {
        getEventsTool,
        createOrderTool,
        manageOrderTool,
        sendTelegramNotificationTool
      }
    })
  },
  bundler: {
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming", "pg"],
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // Inngest Integration Endpoint
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
      },
      // Serve the main HTML page
      {
        path: "/",
        method: "GET",
        handler: async (c) => {
          const {
            readFile
          } = await import('fs/promises');
          try {
            const htmlPath = "/home/runner/workspace/src/mastra/public/index.html";
            const html = await readFile(htmlPath, "utf-8");
            return c.html(html);
          } catch (error) {
            console.error("Error serving HTML:", error);
            return c.text("Page not found", 404);
          }
        }
      },
      // API endpoint for fetching ticket data (events, categories, cities)
      {
        path: "/api/ticket-data",
        method: "GET",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          logger?.info("\u{1F4DD} [API] Fetching ticket data...");
          try {
            const result = await getEventsTool.execute({
              context: {
                includeCategories: true,
                includeCities: true
              },
              mastra: mastra2,
              runtimeContext: {}
            });
            logger?.info(`\u2705 [API] Returning ${result.events.length} events`);
            return c.json(result);
          } catch (error) {
            logger?.error("\u274C [API] Error fetching ticket data:", error);
            return c.json({
              error: "Failed to fetch data"
            }, 500);
          }
        }
      },
      // API endpoint for creating orders
      {
        path: "/api/create-order",
        method: "POST",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          try {
            const body = await c.req.json();
            logger?.info("\u{1F4DD} [API] Creating order:", body);
            if (!body.eventId || typeof body.eventId !== "number") {
              return c.json({
                success: false,
                message: "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435"
              }, 400);
            }
            if (!body.customerName || typeof body.customerName !== "string" || body.customerName.trim().length < 2) {
              return c.json({
                success: false,
                message: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0432\u0430\u0448\u0435 \u0438\u043C\u044F"
              }, 400);
            }
            if (!body.customerPhone || typeof body.customerPhone !== "string" || body.customerPhone.trim().length < 5) {
              return c.json({
                success: false,
                message: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430"
              }, 400);
            }
            const seatsCount = parseInt(body.seatsCount);
            if (isNaN(seatsCount) || seatsCount < 1 || seatsCount > 10) {
              return c.json({
                success: false,
                message: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u043C\u0435\u0441\u0442 \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043E\u0442 1 \u0434\u043E 10"
              }, 400);
            }
            const result = await createOrderTool.execute({
              context: {
                eventId: body.eventId,
                customerName: body.customerName.trim(),
                customerPhone: body.customerPhone.trim(),
                customerEmail: body.customerEmail?.trim() || void 0,
                seatsCount
              },
              mastra: mastra2,
              runtimeContext: {}
            });
            logger?.info("\u2705 [API] Order result:", result);
            if (result.success && result.orderId && result.orderCode) {
              try {
                await sendOrderNotificationToAdmin({
                  orderId: result.orderId,
                  orderCode: result.orderCode,
                  eventName: result.eventName || "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435",
                  eventDate: result.eventDate || "",
                  eventTime: result.eventTime || "",
                  cityName: result.cityName || "",
                  customerName: result.customerName || "",
                  customerPhone: result.customerPhone || "",
                  customerEmail: result.customerEmail,
                  seatsCount: result.seatsCount || 1,
                  totalPrice: result.totalPrice || 0
                });
                logger?.info("\u{1F4E4} [API] Admin notification sent");
              } catch (notifyError) {
                logger?.error("\u26A0\uFE0F [API] Failed to send admin notification:", notifyError);
              }
            }
            return c.json(result);
          } catch (error) {
            logger?.error("\u274C [API] Error creating order:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0437\u0430\u043A\u0430\u0437\u0430"
            }, 500);
          }
        }
      },
      // Telegram webhook for admin callbacks (confirm/reject buttons)
      {
        path: "/webhooks/telegram/action",
        method: "POST",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          try {
            const payload = await c.req.json();
            logger?.info("\u{1F4E5} [TelegramWebhook] Received payload:", payload);
            if (payload.callback_query) {
              const callbackQuery = payload.callback_query;
              const data = callbackQuery.data;
              const messageId = callbackQuery.message?.message_id;
              const chatId = callbackQuery.message?.chat?.id;
              const adminUsername = callbackQuery.from?.username;
              logger?.info("\u{1F518} [TelegramWebhook] Callback:", {
                data,
                messageId,
                chatId
              });
              const [action, orderIdStr] = data.split("_");
              const orderId = parseInt(orderIdStr);
              if (isNaN(orderId)) {
                await answerCallbackQuery(callbackQuery.id, "\u274C \u041E\u0448\u0438\u0431\u043A\u0430: \u043D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ID \u0437\u0430\u043A\u0430\u0437\u0430");
                return c.text("OK", 200);
              }
              let result;
              if (action === "confirm") {
                result = await manageOrderTool.execute({
                  context: {
                    action: "confirm_payment",
                    orderId
                  },
                  mastra: mastra2,
                  runtimeContext: {}
                });
              } else if (action === "reject") {
                result = await manageOrderTool.execute({
                  context: {
                    action: "reject_payment",
                    orderId
                  },
                  mastra: mastra2,
                  runtimeContext: {}
                });
              } else {
                await answerCallbackQuery(callbackQuery.id, "\u274C \u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435");
                return c.text("OK", 200);
              }
              if (result.success && result.order) {
                const status = action === "confirm" ? "confirmed" : "rejected";
                await updateOrderMessageStatus(chatId, messageId, result.order.orderCode, status, adminUsername);
                await answerCallbackQuery(callbackQuery.id, action === "confirm" ? "\u2705 \u041E\u043F\u043B\u0430\u0442\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430!" : "\u274C \u0417\u0430\u043A\u0430\u0437 \u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D");
              } else {
                await answerCallbackQuery(callbackQuery.id, result.message || "\u274C \u041E\u0448\u0438\u0431\u043A\u0430");
              }
              return c.text("OK", 200);
            }
            return c.text("OK", 200);
          } catch (error) {
            logger?.error("\u274C [TelegramWebhook] Error:", error);
            return c.text("OK", 200);
          }
        }
      },
      // Admin panel page
      {
        path: "/admin",
        method: "GET",
        handler: async (c) => {
          const {
            readFile
          } = await import('fs/promises');
          try {
            const htmlPath = "/home/runner/workspace/src/mastra/public/admin.html";
            const html = await readFile(htmlPath, "utf-8");
            return c.html(html);
          } catch (error) {
            return c.text("Page not found", 404);
          }
        }
      },
      // Public event page
      {
        path: "/event/:id",
        method: "GET",
        handler: async (c) => {
          const {
            readFile
          } = await import('fs/promises');
          try {
            const htmlPath = "/home/runner/workspace/src/mastra/public/event.html";
            const html = await readFile(htmlPath, "utf-8");
            return c.html(html);
          } catch (error) {
            return c.text("Page not found", 404);
          }
        }
      },
      // API to get single event details
      {
        path: "/api/event/:id",
        method: "GET",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          const eventId = parseInt(c.req.param("id"));
          if (isNaN(eventId)) {
            return c.json({
              error: "Invalid event ID"
            }, 400);
          }
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT e.*, c.name_ru as category_name, ci.name as city_name 
               FROM events e 
               JOIN categories c ON e.category_id = c.id 
               JOIN cities ci ON e.city_id = ci.id 
               WHERE e.id = $1`, [eventId]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                error: "Event not found"
              }, 404);
            }
            const event = result.rows[0];
            return c.json({
              id: event.id,
              name: event.name,
              description: event.description,
              categoryName: event.category_name,
              cityName: event.city_name,
              date: event.date?.toISOString?.()?.split("T")[0] || event.date,
              time: event.time,
              price: parseFloat(event.price) || 0,
              availableSeats: event.available_seats,
              coverImageUrl: event.cover_image_url,
              slug: event.slug
            });
          } catch (error) {
            logger?.error("\u274C [API] Error fetching event:", error);
            return c.json({
              error: "Failed to fetch event"
            }, 500);
          }
        }
      },
      // Admin API: Verify password
      {
        path: "/api/admin/verify",
        method: "POST",
        handler: async (c) => {
          const body = await c.req.json();
          const adminPassword = process.env.ADMIN_PASSWORD || "admin2024secure";
          if (body.password === adminPassword) {
            return c.json({
              success: true
            });
          }
          return c.json({
            success: false,
            message: "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043F\u0430\u0440\u043E\u043B\u044C"
          }, 401);
        }
      },
      // Admin API: Create event
      {
        path: "/api/admin/events",
        method: "POST",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          const authPassword = c.req.header("X-Admin-Password");
          const adminPassword = process.env.ADMIN_PASSWORD || "admin2024secure";
          if (authPassword !== adminPassword) {
            return c.json({
              success: false,
              message: "Unauthorized"
            }, 401);
          }
          try {
            const body = await c.req.json();
            logger?.info("\u{1F4DD} [Admin API] Creating event:", body);
            const slug = body.name.toLowerCase().replace(/[^\w\sа-яё-]/gi, "").replace(/\s+/g, "-").replace(/--+/g, "-");
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`INSERT INTO events (name, description, category_id, city_id, date, time, price, available_seats, cover_image_url, slug, is_published)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true)
               RETURNING id`, [body.name, body.description, body.categoryId, body.cityId, body.date, body.time, body.price, body.availableSeats, body.coverImageUrl, slug]);
            await pool.end();
            logger?.info("\u2705 [Admin API] Event created:", result.rows[0].id);
            return c.json({
              success: true,
              eventId: result.rows[0].id,
              slug
            });
          } catch (error) {
            logger?.error("\u274C [Admin API] Error creating event:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F"
            }, 500);
          }
        }
      },
      // Admin API: Update event
      {
        path: "/api/admin/events/:id",
        method: "PUT",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          const eventId = parseInt(c.req.param("id"));
          const authPassword = c.req.header("X-Admin-Password");
          const adminPassword = process.env.ADMIN_PASSWORD || "admin2024secure";
          if (authPassword !== adminPassword) {
            return c.json({
              success: false,
              message: "Unauthorized"
            }, 401);
          }
          try {
            const body = await c.req.json();
            logger?.info("\u{1F4DD} [Admin API] Updating event:", eventId, body);
            const slug = body.name.toLowerCase().replace(/[^\w\sа-яё-]/gi, "").replace(/\s+/g, "-").replace(/--+/g, "-");
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query(`UPDATE events SET name=$1, description=$2, category_id=$3, city_id=$4, date=$5, time=$6, price=$7, available_seats=$8, cover_image_url=$9, slug=$10
               WHERE id=$11`, [body.name, body.description, body.categoryId, body.cityId, body.date, body.time, body.price, body.availableSeats, body.coverImageUrl, slug, eventId]);
            await pool.end();
            logger?.info("\u2705 [Admin API] Event updated:", eventId);
            return c.json({
              success: true
            });
          } catch (error) {
            logger?.error("\u274C [Admin API] Error updating event:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F"
            }, 500);
          }
        }
      },
      // Admin API: Delete event
      {
        path: "/api/admin/events/:id",
        method: "DELETE",
        handler: async (c) => {
          const mastra2 = c.get("mastra");
          const logger = mastra2?.getLogger();
          const eventId = parseInt(c.req.param("id"));
          const authPassword = c.req.header("X-Admin-Password");
          const adminPassword = process.env.ADMIN_PASSWORD || "admin2024secure";
          if (authPassword !== adminPassword) {
            return c.json({
              success: false,
              message: "Unauthorized"
            }, 401);
          }
          try {
            logger?.info("\u{1F4DD} [Admin API] Deleting event:", eventId);
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query("DELETE FROM events WHERE id=$1", [eventId]);
            await pool.end();
            logger?.info("\u2705 [Admin API] Event deleted:", eventId);
            return c.json({
              success: true
            });
          } catch (error) {
            logger?.error("\u274C [Admin API] Error deleting event:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u043C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u044F"
            }, 500);
          }
        }
      },
      // Payment Settings API: Get settings
      {
        path: "/api/payment-settings",
        method: "GET",
        handler: async (c) => {
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query("SELECT * FROM payment_settings ORDER BY id DESC LIMIT 1");
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                cardNumber: "",
                cardHolderName: "",
                bankName: ""
              });
            }
            const row = result.rows[0];
            return c.json({
              cardNumber: row.card_number,
              cardHolderName: row.card_holder_name,
              bankName: row.bank_name
            });
          } catch (error) {
            return c.json({
              cardNumber: "",
              cardHolderName: "",
              bankName: ""
            });
          }
        }
      },
      // Payment Settings API: Update settings (admin only)
      {
        path: "/api/admin/payment-settings",
        method: "POST",
        handler: async (c) => {
          const authPassword = c.req.header("X-Admin-Password");
          const adminPassword = process.env.ADMIN_PASSWORD || "admin2024secure";
          if (authPassword !== adminPassword) {
            return c.json({
              success: false,
              message: "Unauthorized"
            }, 401);
          }
          try {
            const body = await c.req.json();
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query(`UPDATE payment_settings SET card_number=$1, card_holder_name=$2, bank_name=$3, updated_at=CURRENT_TIMESTAMP WHERE id=1`, [body.cardNumber, body.cardHolderName, body.bankName]);
            await pool.end();
            return c.json({
              success: true
            });
          } catch (error) {
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F"
            }, 500);
          }
        }
      },
      // Order API: Get order by code
      {
        path: "/api/order/:code",
        method: "GET",
        handler: async (c) => {
          const orderCode = c.req.param("code");
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT o.*, e.name as event_name, e.price 
               FROM orders o 
               JOIN events e ON o.event_id = e.id 
               WHERE o.order_code = $1`, [orderCode]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                error: "Order not found"
              }, 404);
            }
            const order = result.rows[0];
            return c.json({
              id: order.id,
              orderCode: order.order_code,
              eventName: order.event_name,
              customerName: order.customer_name,
              seatsCount: order.seats_count,
              totalPrice: parseFloat(order.total_price) || order.seats_count * parseFloat(order.price),
              status: order.status
            });
          } catch (error) {
            return c.json({
              error: "Failed to fetch order"
            }, 500);
          }
        }
      },
      // Payment page
      {
        path: "/payment",
        method: "GET",
        handler: async (c) => {
          const fs = await import('fs');
          const html = fs.readFileSync("/home/runner/workspace/src/mastra/public/payment.html", "utf-8");
          return c.html(html);
        }
      },
      // Generator page
      {
        path: "/generator",
        method: "GET",
        handler: async (c) => {
          const fs = await import('fs');
          const html = fs.readFileSync("/home/runner/workspace/src/mastra/public/generator.html", "utf-8");
          return c.html(html);
        }
      },
      // Admin Register
      {
        path: "/api/admin/register",
        method: "POST",
        handler: async (c) => {
          try {
            const body = await c.req.json();
            const {
              username,
              displayName,
              password
            } = body;
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const existing = await pool.query("SELECT id FROM admins WHERE username=$1", [username]);
            if (existing.rows.length > 0) {
              await pool.end();
              return c.json({
                success: false,
                message: "\u041B\u043E\u0433\u0438\u043D \u0443\u0436\u0435 \u0437\u0430\u043D\u044F\u0442"
              });
            }
            const result = await pool.query("INSERT INTO admins (username, password_hash, display_name) VALUES ($1, $2, $3) RETURNING id, username, display_name", [username, password, displayName]);
            await pool.end();
            const admin = result.rows[0];
            const token = `${admin.id}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
            return c.json({
              success: true,
              token,
              admin: {
                id: admin.id,
                username: admin.username,
                displayName: admin.display_name
              }
            });
          } catch (error) {
            console.error("Register error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438"
            }, 500);
          }
        }
      },
      // Admin Login
      {
        path: "/api/admin/login",
        method: "POST",
        handler: async (c) => {
          try {
            const body = await c.req.json();
            const {
              username,
              password
            } = body;
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query("SELECT id, username, display_name, password_hash FROM admins WHERE username=$1", [username]);
            await pool.end();
            if (result.rows.length === 0 || result.rows[0].password_hash !== password) {
              return c.json({
                success: false,
                message: "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043B\u043E\u0433\u0438\u043D \u0438\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C"
              });
            }
            const admin = result.rows[0];
            const token = `${admin.id}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
            return c.json({
              success: true,
              token,
              admin: {
                id: admin.id,
                username: admin.username,
                displayName: admin.display_name
              }
            });
          } catch (error) {
            console.error("Login error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0432\u0445\u043E\u0434\u0430"
            }, 500);
          }
        }
      },
      // Generate Event (multi-admin)
      {
        path: "/api/admin/generate-event",
        method: "POST",
        handler: async (c) => {
          try {
            const authHeader = c.req.header("Authorization");
            if (!authHeader?.startsWith("Bearer ")) {
              return c.json({
                success: false,
                message: "Unauthorized"
              }, 401);
            }
            const token = authHeader.split(" ")[1];
            const adminId = parseInt(token.split("_")[0]);
            if (!adminId) {
              return c.json({
                success: false,
                message: "Invalid token"
              }, 401);
            }
            const body = await c.req.json();
            const slug = `${body.name.toLowerCase().replace(/[^\w\sа-яё-]/gi, "").replace(/\s+/g, "-").replace(/--+/g, "-")}-${Math.random().toString(36).slice(2, 8)}`;
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query(`INSERT INTO events (name, description, category_id, city_id, date, time, price, available_seats, cover_image_url, slug, is_published, admin_id)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true, $11)`, [body.name, body.description, body.categoryId, body.cityId, body.date, body.time, body.price, body.availableSeats, body.coverImageUrl, slug, adminId]);
            await pool.end();
            return c.json({
              success: true,
              slug
            });
          } catch (error) {
            console.error("Generate event error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438"
            }, 500);
          }
        }
      },
      // My Events (admin-specific)
      {
        path: "/api/admin/my-events",
        method: "GET",
        handler: async (c) => {
          try {
            const authHeader = c.req.header("Authorization");
            if (!authHeader?.startsWith("Bearer ")) {
              return c.json({
                events: []
              });
            }
            const token = authHeader.split(" ")[1];
            const adminId = parseInt(token.split("_")[0]);
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT e.*, c.name as city_name, cat.name_ru as category_name
               FROM events e
               LEFT JOIN cities c ON e.city_id = c.id
               LEFT JOIN categories cat ON e.category_id = cat.id
               WHERE e.admin_id = $1
               ORDER BY e.created_at DESC`, [adminId]);
            await pool.end();
            const events = result.rows.map((e) => ({
              id: e.id,
              name: e.name,
              slug: e.slug,
              cityName: e.city_name,
              categoryName: e.category_name,
              date: e.date?.toISOString?.()?.split("T")[0] || e.date,
              time: e.time,
              price: parseFloat(e.price) || 0,
              availableSeats: e.available_seats
            }));
            return c.json({
              events
            });
          } catch (error) {
            console.error("My events error:", error);
            return c.json({
              events: []
            });
          }
        }
      },
      // My Payment Settings (get)
      {
        path: "/api/admin/my-payment-settings",
        method: "GET",
        handler: async (c) => {
          try {
            const authHeader = c.req.header("Authorization");
            if (!authHeader?.startsWith("Bearer ")) {
              return c.json({
                cardNumber: "",
                cardHolderName: "",
                bankName: ""
              });
            }
            const token = authHeader.split(" ")[1];
            const adminId = parseInt(token.split("_")[0]);
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query("SELECT * FROM admin_payment_settings WHERE admin_id=$1", [adminId]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                cardNumber: "",
                cardHolderName: "",
                bankName: ""
              });
            }
            const row = result.rows[0];
            return c.json({
              cardNumber: row.card_number,
              cardHolderName: row.card_holder_name,
              bankName: row.bank_name
            });
          } catch (error) {
            return c.json({
              cardNumber: "",
              cardHolderName: "",
              bankName: ""
            });
          }
        }
      },
      // My Payment Settings (save)
      {
        path: "/api/admin/my-payment-settings",
        method: "POST",
        handler: async (c) => {
          try {
            const authHeader = c.req.header("Authorization");
            if (!authHeader?.startsWith("Bearer ")) {
              return c.json({
                success: false,
                message: "Unauthorized"
              }, 401);
            }
            const token = authHeader.split(" ")[1];
            const adminId = parseInt(token.split("_")[0]);
            const body = await c.req.json();
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query(`INSERT INTO admin_payment_settings (admin_id, card_number, card_holder_name, bank_name)
               VALUES ($1, $2, $3, $4)
               ON CONFLICT (admin_id) DO UPDATE SET
               card_number = $2, card_holder_name = $3, bank_name = $4, updated_at = CURRENT_TIMESTAMP`, [adminId, body.cardNumber, body.cardHolderName, body.bankName]);
            await pool.end();
            return c.json({
              success: true
            });
          } catch (error) {
            console.error("Save payment settings error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F"
            }, 500);
          }
        }
      },
      // Public event page by slug
      {
        path: "/e/:slug",
        method: "GET",
        handler: async (c) => {
          const fs = await import('fs');
          const html = fs.readFileSync("/home/runner/workspace/src/mastra/public/ticket.html", "utf-8");
          return c.html(html);
        }
      },
      // API: Get event by slug
      {
        path: "/api/e/:slug",
        method: "GET",
        handler: async (c) => {
          const slug = c.req.param("slug");
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT e.*, c.name as city_name, cat.name_ru as category_name
               FROM events e
               LEFT JOIN cities c ON e.city_id = c.id
               LEFT JOIN categories cat ON e.category_id = cat.id
               WHERE e.slug = $1 AND e.is_published = true`, [slug]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                error: "Event not found"
              }, 404);
            }
            const e = result.rows[0];
            return c.json({
              id: e.id,
              adminId: e.admin_id,
              name: e.name,
              description: e.description,
              categoryName: e.category_name,
              cityName: e.city_name,
              date: e.date?.toISOString?.()?.split("T")[0] || e.date,
              time: e.time,
              price: parseFloat(e.price) || 0,
              availableSeats: e.available_seats,
              coverImageUrl: e.cover_image_url,
              slug: e.slug
            });
          } catch (error) {
            console.error("Get event error:", error);
            return c.json({
              error: "Failed to fetch event"
            }, 500);
          }
        }
      },
      // Create ticket order - sends notification to admin immediately
      {
        path: "/api/create-ticket-order",
        method: "POST",
        handler: async (c) => {
          try {
            const body = await c.req.json();
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const eventResult = await pool.query(`SELECT e.id, e.price, e.available_seats, e.admin_id, e.name, e.date, e.time, c.name as city_name
               FROM events e
               LEFT JOIN cities c ON e.city_id = c.id
               WHERE e.slug=$1`, [body.eventSlug]);
            if (eventResult.rows.length === 0) {
              await pool.end();
              return c.json({
                success: false,
                message: "\u041C\u0435\u0440\u043E\u043F\u0440\u0438\u044F\u0442\u0438\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
              });
            }
            const event = eventResult.rows[0];
            if (event.available_seats < body.seatsCount) {
              await pool.end();
              return c.json({
                success: false,
                message: "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u043C\u0435\u0441\u0442"
              });
            }
            const orderCode = `TK${Date.now().toString(36).toUpperCase()}`;
            const totalPrice = parseFloat(event.price) * body.seatsCount;
            const orderResult = await pool.query(`INSERT INTO orders (event_id, admin_id, customer_name, customer_phone, customer_email, seats_count, total_price, order_code, status)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
               RETURNING id`, [event.id, event.admin_id, body.customerName, body.customerPhone, body.customerEmail, body.seatsCount, totalPrice, orderCode]);
            await pool.query("UPDATE events SET available_seats = available_seats - $1 WHERE id = $2", [body.seatsCount, event.id]);
            await pool.end();
            try {
              await sendOrderNotificationToAdmin({
                orderId: orderResult.rows[0].id,
                orderCode,
                eventName: event.name,
                eventDate: event.date?.toISOString?.()?.split("T")[0] || String(event.date),
                eventTime: event.time || "",
                cityName: event.city_name || "",
                customerName: body.customerName,
                customerPhone: body.customerPhone,
                customerEmail: body.customerEmail,
                seatsCount: body.seatsCount,
                totalPrice
              });
              console.log("\u{1F4E4} [API] Admin notification sent for new order:", orderCode);
            } catch (notifyError) {
              console.error("\u26A0\uFE0F [API] Failed to send admin notification:", notifyError);
            }
            return c.json({
              success: true,
              orderCode
            });
          } catch (error) {
            console.error("Create order error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u0437\u0430\u043A\u0430\u0437\u0430"
            }, 500);
          }
        }
      },
      // Get ticket order by code
      {
        path: "/api/ticket-order/:code",
        method: "GET",
        handler: async (c) => {
          const orderCode = c.req.param("code");
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT o.*, e.name as event_name, e.date, e.time, e.price
               FROM orders o
               JOIN events e ON o.event_id = e.id
               WHERE o.order_code = $1`, [orderCode]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                error: "Order not found"
              }, 404);
            }
            const o = result.rows[0];
            return c.json({
              id: o.id,
              orderCode: o.order_code,
              eventName: o.event_name,
              customerName: o.customer_name,
              seatsCount: o.seats_count,
              totalPrice: parseFloat(o.total_price),
              status: o.status,
              eventDate: o.date,
              eventTime: o.time
            });
          } catch (error) {
            return c.json({
              error: "Failed to fetch order"
            }, 500);
          }
        }
      },
      // Get payment settings for order
      {
        path: "/api/ticket-order/:code/payment-settings",
        method: "GET",
        handler: async (c) => {
          const orderCode = c.req.param("code");
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            const result = await pool.query(`SELECT aps.* FROM admin_payment_settings aps
               JOIN orders o ON o.admin_id = aps.admin_id
               WHERE o.order_code = $1`, [orderCode]);
            await pool.end();
            if (result.rows.length === 0) {
              return c.json({
                cardNumber: "",
                cardHolderName: "",
                bankName: ""
              });
            }
            const row = result.rows[0];
            return c.json({
              cardNumber: row.card_number,
              cardHolderName: row.card_holder_name,
              bankName: row.bank_name
            });
          } catch (error) {
            return c.json({
              cardNumber: "",
              cardHolderName: "",
              bankName: ""
            });
          }
        }
      },
      // Mark order as paid (waiting confirmation) - notification already sent when order was created
      {
        path: "/api/ticket-order/:code/mark-paid",
        method: "POST",
        handler: async (c) => {
          const orderCode = c.req.param("code");
          try {
            const pg = await import('pg');
            const pool = new pg.Pool({
              connectionString: process.env.DATABASE_URL
            });
            await pool.query("UPDATE orders SET status='waiting_confirmation' WHERE order_code=$1", [orderCode]);
            await pool.end();
            console.log("\u{1F4DD} [API] Order marked as waiting confirmation:", orderCode);
            return c.json({
              success: true
            });
          } catch (error) {
            console.error("Mark paid error:", error);
            return c.json({
              success: false,
              message: "\u041E\u0448\u0438\u0431\u043A\u0430"
            }, 500);
          }
        }
      },
      // Pay page
      {
        path: "/pay",
        method: "GET",
        handler: async (c) => {
          const fs = await import('fs');
          const html = fs.readFileSync("/home/runner/workspace/src/mastra/public/pay.html", "utf-8");
          return c.html(html);
        }
      }
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
